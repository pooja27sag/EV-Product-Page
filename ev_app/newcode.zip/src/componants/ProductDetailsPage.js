import React, { useState } from 'react';
import './ProductDetailsPage.css';
import { imagePath } from '../utils/IpConstantFile';

const ProductDetailsPage = ({ productDetails, refProp }) => {
    // const productDetails = {
    //     "_id": "6828a480eddbaee80245efc7",
    //     "title": " Ather 450X 3.7KWh",
    //     "price": " ₹1,67,407.00",
    //     "emi": " EMI starts at ₹5168 per month",
    //     "description": "The Ather 450X 3.7 kWh is a premium electric scooter built for high-performance and smart urban commuting. With a 3.7 kWh battery, it offers a range of 146 km per charge and a top speed of 80 km/h, making it ideal for both short and long city rides. Packed with features like real-time navigation, Bluetooth connectivity, and multiple ride modes, it delivers a tech-forward, customizable experience. Safety is enhanced through Ather’s SkidControl™ and FallSafe™ systems, while 22 liters of under-seat storage adds everyday convenience.",
    //     "longDescription": " The Ather 450X 3.7 kWh price hovers around ₹1,68,719...",
    //     "brand": " Ather Energy",
    //     "category": " Electric Vehicle",
    //     "colors": [
    //         "Hyper Sand",
    //         "Space Gray",
    //         "Lunar White"
    //     ],
    //     "kwhBattery": " 3.7",
    //     "kmRange": " 146",
    //     "chargingTime": " 5:45",
    //     "variants": [
    //         {
    //             "color": "Hyper Sand",
    //             "image": "1747494016911-326444972-Rizta-image-324x243.png"
    //         },
    //         {
    //             "color": "Space Gray",
    //             "image": "1747494016911-530647035-Matte-coars-324x243.png"
    //         },
    //         {
    //             "color": "Lunar White",
    //             "image": "1747494016911-51753980-cosmic-black-324x243.png"
    //         }
    //     ],
    //     "specifications": {
    //         "general": {
    //             "exShowroomPrice": "154,999",
    //             "certifiedRange": "150 km",
    //             "trueRange": "110 km",
    //             "motorPowerNominalPeak": "6.4 kW",
    //             "chargingTime": "5h 45m",
    //             "fastCharging": "0-50% SOC ( 1.5 km/min ) 50-80% SOC ( 1 km/min )"
    //         },
    //         "technical": {
    //             "motorPowerNominalPeak": "6.4 kW",
    //             "motorType": "PMSM",
    //             "batteryType": "Lithium-ion",
    //             "batteryCapacity": "3.7 kWh",
    //             "keyType": "-",
    //             "chargerType": "-",
    //             "ignition": "Push Button Start",
    //             "frontTyreSize": "90/90-12 tubeless tyres",
    //             "rearTyreSize": "100/80-12 tubeless tyres",
    //             "brakingSystem": "Combined braking system & regenerative braking",
    //             "frontBrakeDiameter": "-",
    //             "rearBrakeDiameter": "-",
    //             "frontBrakeType": "Hydraulically actuated triple-piston calliper disc",
    //             "rearBrakeType": "Hydraulically actuated single-piston calliper disc",
    //             "frameType": "-",
    //             "transmission": "Belt drive"
    //         },
    //         "performance": {
    //             "topSpeed": "90 km/h",
    //             "certifiedRange": "150 km",
    //             "ridingModes": "Smart Eco, Eco Ride & Sport",
    //             "trueRangeEcoMode": "110 km",
    //             "trueRangeNormalMode": "",
    //             "acceleration_0_40kmh": "3.3 s",
    //             "braking_60_0kmph": "",
    //             "maxTorque": "26 Nm"
    //         },
    //         "features": {
    //             "instrumentCluster": "17.7 cm (7”) TFT touchscreen",
    //             "navigation": "",
    //             "fastCharging": "",
    //             "reverseAssist": "Yes",
    //             "cruiseControl": "",
    //             "chargingStationLocator": "Yes",
    //             "sideStandAlert": "",
    //             "sideStandMotorCutoff": "Yes",
    //             "safeguards": "",
    //             "usbPorts": "",
    //             "music": "Yes",
    //             "remoteBootUnlock": "",
    //             "gpsConnectivity": "",
    //             "advancedRegen": "",
    //             "vacationMode": "",
    //             "predictiveMaintenance": "",
    //             "proximityUnlock": "",
    //             "hillHold": "",
    //             "footpegs": ""
    //         },
    //         "weightAndDimensions": {
    //             "weight": "111.6 kg",
    //             "length": "189.1 cm",
    //             "width": "73.9 cm",
    //             "height": "111.4 cm",
    //             "groundClearance": "",
    //             "gradeability": "15 Degree",
    //             "wheelbase": "129.6 cm",
    //             "seatHeight": "78 cm",
    //             "seatLength": "",
    //             "floorboardSize": "",
    //             "waterWade": "30 cm"
    //         },
    //         "electricals": {
    //             "headlight": "LED",
    //             "tailight": "LED",
    //             "indicators": "LED",
    //             "projector": "",
    //             "hazardLight": "",
    //             "bootLight": ""
    //         },
    //         "storage": {
    //             "underSeat": "22L",
    //             "glovebox": ""
    //         },
    //         "ingressProtection": {
    //             "battery": "IP67",
    //             "motor": "IP66",
    //             "controller": "IP65"
    //         },
    //         "chassisAndSuspension": {
    //             "nameType": "Precision machined hybrid chassis",
    //             "frontSuspension": "Telescopic forks",
    //             "rearSuspension": "Symmetrically mounted progressive monoshock"
    //         },
    //         "misc": {
    //             "bagHook": "Yes",
    //             "pannierStay": "",
    //             "accessoryMounts": ""
    //         },
    //         "warranty": {
    //             "vehicleWarranty": "3 years/30,000 km whichever is earlier",
    //             "batteryWarranty": "3 years/30,000 km whichever is earlier"
    //         },
    //         "colors": []
    //     },
    //     "subscription": {
    //         "plan1": {
    //             "title": "Ather 450X 3.7kWh (With Ather Pro and Extended Warranty)",
    //             "data": [
    //                 {
    //                     "duration": "36 months",
    //                     "subscription": "5249",
    //                     "deposit": "12999"
    //                 },
    //                 {
    //                     "duration": "24 months",
    //                     "subscription": "6799",
    //                     "deposit": "12999"
    //                 },
    //                 {
    //                     "duration": "12 months",
    //                     "subscription": "9999",
    //                     "deposit": "12999"
    //                 }
    //             ]
    //         },
    //         "plan2": {
    //             "title": "Monthly Subscription as per Exchange Vehicle Age",
    //             "data": [
    //                 {
    //                     "duration": "36 months",
    //                     "upto2": "3499",
    //                     "y3to4": "3699",
    //                     "y5to6": "-",
    //                     "deposit": "-"
    //                 },
    //                 {
    //                     "duration": "24 months",
    //                     "upto2": "4299",
    //                     "y3to4": "4599",
    //                     "y5to6": "-",
    //                     "deposit": "-"
    //                 },
    //                 {
    //                     "duration": "12 months",
    //                     "upto2": "5249",
    //                     "y3to4": "5599",
    //                     "y5to6": "-",
    //                     "deposit": "-"
    //                 }
    //             ]
    //         }
    //     },
    //     "__v": 0
    // };

    const [readMore, setReadMore] = useState(false);

    return (
        <div className="product-details-container" ref={refProp}>
            <div className="breadcrumbs" style={{ alignItems: "center", justifyContent: "flex-start", display: "flex", gap: "4px" }}
            >
                <a href="/">Home</a> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg> <a href="/shop">Shop</a> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg> <a href="/product-category/electric-vehicle">Electric Vehicle</a> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg> {productDetails?.title}
            </div>
            <div className="product-main">
                <div className="product-gallery">
                    <div className="image-gallery-wrapper">
                        <img
                            src={imagePath + "/" + productDetails?.variants[0].image}
                            alt={productDetails?.title}
                            className="product-image"
                        />
                    </div>

                    <div className="product-features">
                        <div className="feature">
                            <img src="battery.svg" alt="Battery" />
                            <div className="value">{productDetails?.kwhBattery}</div>
                            <div className="label">Battery</div>
                        </div>
                        <div className="feature">
                            <img src="/range.svg" alt="Range" />
                            <div className="value">{productDetails?.kmRange}</div>
                            <div className="label">Range</div>
                        </div>
                        <div className="feature">
                            <img src="/charge.svg" alt="Charging Time" />
                            <div className="value">{productDetails?.chargingTime}</div>
                            <div className="label">Charging Time</div>
                        </div>
                    </div>
                </div>

                <div className="product-summary">
                    <div className="product-title-wrapper">
                        <input type="checkbox" className="product-checkbox" />
                        <h1 className="product-title">{productDetails?.title}</h1>
                    </div>
                    <p className="price">{productDetails?.price}</p>

                    <div className="emi-section">
                        <p>EMI starts at ₹5168 per month.</p>
                        <select>
                            <option value="emi">EMI</option>
                            <option value="subscriptions">Subscriptions</option>
                        </select>
                    </div>

                    <div className="product-short-description">
                        <span>
                            {productDetails?.description}
                        </span>
                        <button onClick={() => setReadMore(!readMore)} className="read-more-btn">
                            {readMore ? 'Read Less' : 'Read More'}
                        </button>
                    </div>
                    <hr className="description-divider" />

                    <div className="product-meta">
                        <span className="meta-item">Brand: Ather Energy</span>
                        <span className="meta-item">Category: Electric Vehicle</span>
                    </div>
                    <hr className="description-divider" />

                    <div className="color-selector">
                        <label>Color</label>
                        <select>
                            <option value="hyper-sand">Hyper sand</option>
                        </select>
                    </div>

                    <div className="addons">
                        <label className="addon-section">Addons</label>
                        <label>
                            <input type="checkbox" />
                            Ather Pro
                        </label>
                    </div>
                    <div className="exchange-section">
                        <span className="exchange-text">Save more with exchange</span>
                    </div>
                    <div className="pin-code-wrapper">
                        <label className="pin-code-header">Pin Code</label>
                        <div className="pin-code-section">
                            <div className="pin-code-input-wrapper">
                                <input type="text" placeholder="Enter Pin Code" />
                                <button className="check-btn">Check</button>
                            </div>
                            <button className="add-to-cart-btn">Add to cart</button>
                        </div>
                        <p className="pin-code-note">*Please enter your pincode to check availability in your area.</p>
                    </div>


                </div>
            </div>
        </div>
    );
};

export default ProductDetailsPage;