import React, { useState } from 'react';
// import './ProductDetails.css';
import './ProductSpecs.css';
// import './ProductDetailsPage.css';

import { imagePath } from '../utils/IpConstantFile';

const ProductDetails = ({ productDetails, refProp }) => {
    const [readMore, setReadMore] = useState(false);

    return (
        <div className="product-details-container" ref={refProp}>
            <div className="breadcrumbs" style={{ alignItems: "center", justifyContent: "flex-start", display: "flex", gap: "4px" }}
            >
                <a href="/">Home</a> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg> <a href="/shop">Shop</a> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg> <a href="/product-category/electric-vehicle">Electric Vehicle</a> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg> {productDetails?.title}
            </div>

            <div className="product-main">
                <div className="product-gallery">
                    <div className='image-gallery-wrapper'>
                        <img
                            src={imagePath + "/" + productDetails?.variants[0]?.image}
                            alt={productDetails?.title}
                            className="product-image"
                        />
                    </div>

                    <div className="product-features">
                        <div className="feature">
                            <img src="battery.svg" alt="Battery" />
                            <div className="value">{productDetails?.kwhBattery}</div>
                            <div className="label">Battery</div>
                        </div>
                        <div className="feature">
                            <img src="/range.svg" alt="Range" />
                            <div className="value">{productDetails?.kmRange}</div>
                            <div className="label">Range</div>
                        </div>
                        <div className="feature">
                            <img src="/charge.svg" alt="Charging Time" />
                            <div className="value">{productDetails?.chargingTime}</div>
                            <div className="label">Charging Time</div>
                        </div>
                    </div>

                </div>

                <div className="product-summary">
                    <h1 className="product-title">{productDetails?.title}</h1>
                    <p className="price">{productDetails?.price}</p>

                    <div className="emi-section">
                        <p>EMI starts at ₹5168 per month.</p>
                        <select>
                            <option value="emi">EMI</option>
                            <option value="subscriptions">Subscriptions</option>
                        </select>
                    </div>

                    <div className="product-short-description">
                        <span>

                            {productDetails?.description}
                        </span>
                        <button onClick={() => setReadMore(!readMore)} className="read-more-btn">
                            {readMore ? 'Read Less' : 'Read More'}
                        </button>
                    </div>

                    <hr className="description-divider" />

                    <div className="product-meta">
                        <span className="meta-item">Brand: Ather Energy</span>
                        <span className="meta-item">Category: Electric Vehicle</span>
                    </div>
                    <hr className="description-divider" />

                    <div className="color-selector">
                        <label>Color</label>
                        <select>
                            <option value="hyper-sand">Hyper sand</option>
                        </select>
                    </div>

                    <div className="addons">
                        <label className="addon-section">Addons</label>
                        <label>
                            <input type="checkbox" />
                            Ather Pro
                        </label>
                    </div>
                    <div className="exchange-section">
                        <span className="exchange-text">Save more with exchange</span>
                    </div>
                    <div className="pin-code-wrapper">
                        <label className="pin-code-header">Pin Code</label>
                        <div className="pin-code-section">
                            <div className="pin-code-input-wrapper">
                                <input type="text" placeholder="Enter Pin Code" />
                                <button className="check-btn">Check</button>
                            </div>
                            <button className="add-to-cart-btn">Add to cart</button>
                        </div>
                        <p className="pin-code-note">*Please enter your pincode to check availability in your area.</p>
                    </div>

                    {/* <div className="product-meta">
                        <p>Brand: <a href="/shop/brand-ather">Ather Energy</a></p>
                        <p>Category: <a href="/product-category/electric-vehicle">Electric Vehicle</a></p>
                        <p>Tag: <a href="/product-tag/vehicle">Vehicle</a></p>
                    </div>

                    <button className="buy-btn">Buy or Subscribe</button> */}
                </div>
            </div>
        </div>
    );
};

export default ProductDetails;
