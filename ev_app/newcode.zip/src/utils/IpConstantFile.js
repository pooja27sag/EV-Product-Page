
export const serverIpPath = "http://localhost:4000"; // or your base URL
export const imagePath = "http://localhost:4000/uploads/"; // or your base URL
